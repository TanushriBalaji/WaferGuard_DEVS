import joblib
import pandas as pd

MODEL_PATH = "/content/waferguard_model_final.joblib"

def predict_wafers(input_df, model_path=MODEL_PATH):
    artifact = joblib.load(model_path)
    model = artifact["model"]
    sensor_columns = artifact["sensor_columns"]
    threshold = artifact["threshold"]

    missing = [c for c in sensor_columns if c not in input_df.columns]
    if missing:
        raise ValueError(
            f"Input is missing {len(missing)} required sensor columns."
        )

    X_new = input_df[sensor_columns].copy()
    probabilities = model.predict_proba(X_new)[:, 1]
    predictions = probabilities >= threshold

    return pd.DataFrame({
        "failure_probability": probabilities,
        "prediction": [
            "FAIL" if p else "PASS" for p in predictions
        ]
    })
