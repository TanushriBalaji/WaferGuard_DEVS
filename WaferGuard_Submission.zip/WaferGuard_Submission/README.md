# WaferGuard AI

AI-assisted semiconductor wafer quality and fault detection.

## Model
Tuned Random Forest classifier with median imputation,
variance filtering, robust scaling, and feature selection.

## Input
A pandas DataFrame containing the expected 590 sensor columns.

## Output
Failure probability and PASS/FAIL prediction.

## Run inference
Import `predict_wafers` from `inference.py`.

## Important limitations
The dataset is small and imbalanced. Validation results are estimates,
not guarantees of performance on the organizers' hidden test set.
A FAIL prediction is an inspection flag, not confirmation of a defect.
